import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";

import { Shell, rarityTextClass } from "@/components/Shell";
import { BADGES } from "@/lib/badges";
import { computeStats, entryForWord, loadPlayer, type PlayerState } from "@/lib/player";
import { explainProperty, scoreWord } from "@/lib/scoring";

export const Route = createFileRoute("/stats")({
  head: () => ({
    meta: [
      { title: "Your Stats & Word History — Word RNG" },
      {
        name: "description",
        content: "Track your streak, total XP, badge collection and every word you have been given so far.",
      },
      { property: "og:title", content: "Your Stats & Word History — Word RNG" },
      {
        property: "og:description",
        content: "Streaks, badges and the full property breakdown of every word you have played.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: StatsPage,
});

function StatsPage() {
  const [player, setPlayer] = useState<PlayerState | null>(null);
  const [openDate, setOpenDate] = useState<string | null>(null);

  useEffect(() => {
    setPlayer(loadPlayer());
  }, []);

  const stats = useMemo(() => (player ? computeStats(player) : null), [player]);

  if (!player || !stats) {
    return (
      <Shell>
        <div className="panel h-72 animate-pulse" />
      </Shell>
    );
  }

  const badgePercent = Math.round((player.badges.length / BADGES.length) * 100);

  const cards = [
    { label: "Current streak", value: `🔥 ${stats.currentStreak}` },
    { label: "Longest streak", value: `🏆 ${stats.longestStreak}` },
    { label: "Words played", value: stats.totalWords.toLocaleString() },
    { label: "Total XP", value: stats.totalXp.toLocaleString() },
    { label: "Best score", value: stats.highestXp.toLocaleString() },
    { label: "Average XP", value: stats.averageXp.toLocaleString() },
  ];

  return (
    <Shell>
      <h1 className="font-display text-3xl font-bold">Your stats</h1>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {cards.map((card) => (
          <div key={card.label} className="panel px-4 py-5">
            <p className="label-xs">{card.label}</p>
            <p className="mt-1 font-display text-2xl font-bold tabular-nums">{card.value}</p>
          </div>
        ))}
        <div className="panel px-4 py-5">
          <p className="label-xs">Best rarity</p>
          <p className={`mt-1 font-display text-2xl font-bold ${rarityTextClass[stats.highestRarity] ?? ""}`}>
            {stats.highestRarity}
          </p>
        </div>
      </div>

      <h2 className="mt-10 font-display text-xl font-bold">
        Badges <span className="text-muted-foreground">{player.badges.length}/{BADGES.length} · {badgePercent}%</span>
      </h2>
      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {BADGES.map((badge) => {
          const owned = player.badges.includes(badge.id);
          return (
            <div
              key={badge.id}
              className={`panel px-4 py-4 ${owned ? "" : "opacity-60"}`}
              title={owned ? badge.description : badge.hint}
            >
              <p className="text-lg">{owned ? badge.icon : "🔒"}</p>
              <p className="mt-1 font-display text-sm font-semibold">{owned ? badge.name : "???"}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                {owned ? badge.description : "You haven't discovered this pattern yet."}
              </p>
            </div>
          );
        })}
      </div>

      <h2 className="mt-10 font-display text-xl font-bold">Word history</h2>
      <div className="panel mt-4 divide-y divide-border">
        {player.history.length === 0 && (
          <p className="px-5 py-6 text-sm text-muted-foreground">No words yet. Go generate today's.</p>
        )}
        {player.history.map((item) => {
          const entry = entryForWord(item.word);
          const open = openDate === item.date;
          return (
            <div key={item.date}>
              <button
                onClick={() => setOpenDate(open ? null : item.date)}
                className="flex w-full items-center gap-3 px-5 py-3 text-left transition-colors hover:bg-surface-strong"
              >
                <span className="w-20 text-xs text-muted-foreground">{item.date}</span>
                <span className="min-w-0 flex-1 truncate font-display text-sm font-semibold uppercase">
                  {item.word}
                </span>
                <span className={`text-xs font-semibold ${rarityTextClass[item.rarity] ?? ""}`}>{item.rarity}</span>
                <span className="w-20 text-right font-display text-sm font-bold tabular-nums text-xp">
                  {item.xp.toLocaleString()}
                </span>
              </button>
              {open && entry && (
                <div className="space-y-1 px-5 pb-4">
                  <p className="text-xs text-muted-foreground">{entry.definition}</p>
                  {scoreWord(entry).properties.map((prop) => (
                    <div key={prop.key} className="flex items-start justify-between gap-4 py-1 text-xs">
                      <span>
                        {prop.icon} {prop.label}
                        {prop.count > 1 && ` ×${prop.count}`}
                        <span className="block text-muted-foreground">{explainProperty(prop)}</span>
                      </span>
                      <span className="shrink-0 font-semibold text-xp">+{prop.xp.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </Shell>
  );
}
