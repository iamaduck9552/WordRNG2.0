import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import { Shell, rarityTextClass } from "@/components/Shell";
import { fetchLeaderboard, type LeaderboardRow } from "@/lib/leaderboard";
import { loadPlayer, localDateKey } from "@/lib/player";

export const Route = createFileRoute("/leaderboard")({
  head: () => ({
    meta: [
      { title: "Today's Leaderboard — Word RNG" },
      {
        name: "description",
        content: "See today's highest scoring words and how your own random word ranks against other players.",
      },
      { property: "og:title", content: "Today's Leaderboard — Word RNG" },
      {
        property: "og:description",
        content: "The rarest words generated today, ranked by XP.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LeaderboardPage,
});

function LeaderboardPage() {
  const [rows, setRows] = useState<LeaderboardRow[] | null>(null);
  const [playerId, setPlayerId] = useState("");
  const [revealed, setRevealed] = useState<Set<string>>(new Set());
  const [error, setError] = useState(false);

  useEffect(() => {
    setPlayerId(loadPlayer().id);
    fetchLeaderboard(localDateKey())
      .then(setRows)
      .catch(() => setError(true));
  }, []);

  return (
    <Shell>
      <h1 className="font-display text-3xl font-bold">Today's leaderboard</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Everyone gets a different word. Tap a row to reveal someone's word.
      </p>

      <div className="panel mt-6 divide-y divide-border">
        {error && <p className="px-5 py-6 text-sm text-muted-foreground">Scores are unavailable right now.</p>}
        {!error && rows === null && <div className="h-40 animate-pulse" />}
        {rows?.length === 0 && (
          <p className="px-5 py-6 text-sm text-muted-foreground">No results yet today. Be the first.</p>
        )}
        {rows?.map((row, index) => {
          const isMe = row.player_id === playerId;
          const show = revealed.has(row.player_id) || isMe;
          return (
            <button
              key={row.player_id}
              onClick={() =>
                setRevealed((prev) => {
                  const next = new Set(prev);
                  next.add(row.player_id);
                  return next;
                })
              }
              className={`flex w-full items-center gap-4 px-5 py-3 text-left transition-colors hover:bg-surface-strong ${
                isMe ? "bg-secondary" : ""
              }`}
            >
              <span className="w-6 font-display text-sm text-muted-foreground">{index + 1}</span>
              <span className="min-w-0 flex-1 truncate text-sm font-medium">
                {row.player_name}
                {isMe && <span className="text-muted-foreground"> (you)</span>}
              </span>
              <span className="hidden w-40 truncate font-display text-sm uppercase text-muted-foreground sm:block">
                {show ? row.word : `${row.word.slice(0, 3)}…`}
              </span>
              <span className={`w-20 text-right text-xs font-semibold ${rarityTextClass[row.rarity] ?? ""}`}>
                {row.rarity}
              </span>
              <span className="w-20 text-right font-display text-sm font-bold tabular-nums text-xp">
                {row.xp.toLocaleString()}
              </span>
            </button>
          );
        })}
      </div>
    </Shell>
  );
}
