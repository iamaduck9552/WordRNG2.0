import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { Shell, rarityBorderClass, rarityTextClass } from "@/components/Shell";
import { badgesFor } from "@/lib/badges";
import {
  computeStats,
  dailyWordFor,
  entryForWord,
  formatCountdown,
  loadPlayer,
  localDateKey,
  msUntilTomorrow,
  recordResult,
  savePlayer,
  todaysResult,
  type PlayerState,
} from "@/lib/player";
import { fetchDayScores, submitResult } from "@/lib/leaderboard";
import { explainProperty, rarityOf, scoreWord, type ScoredProperty } from "@/lib/scoring";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Word RNG — One word. One chance. Yours is probably weird." },
      {
        name: "description",
        content:
          "Every day you get your own random English word. Discover its hidden properties, earn XP for every rare pattern, and see how your word ranks against today's players.",
      },
      { property: "og:title", content: "Word RNG — One word. One chance." },
      {
        property: "og:description",
        content: "Generate your daily word, uncover its rare properties and chase a mythic score.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PlayPage,
});

function useCountUp(target: number) {
  const [value, setValue] = useState(0);
  const frame = useRef<number | null>(null);
  useEffect(() => {
    const start = value;
    const delta = target - start;
    if (delta === 0) return;
    const duration = 520;
    const begin = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - begin) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setValue(Math.round(start + delta * eased));
      if (t < 1) frame.current = requestAnimationFrame(tick);
    };
    frame.current = requestAnimationFrame(tick);
    return () => {
      if (frame.current) cancelAnimationFrame(frame.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target]);
  return value;
}

type Phase = "idle" | "suspense" | "reveal" | "done";

function PlayPage() {
  const [player, setPlayer] = useState<PlayerState | null>(null);
  const [phase, setPhase] = useState<Phase>("idle");
  const [revealed, setRevealed] = useState(0);
  const [openProp, setOpenProp] = useState<string | null>(null);
  const [countdown, setCountdown] = useState("");
  const [beatPercent, setBeatPercent] = useState<number | null>(null);
  const [copied, setCopied] = useState(false);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  const today = localDateKey();

  useEffect(() => {
    const loaded = loadPlayer();
    setPlayer(loaded);
    if (todaysResult(loaded, today)) setPhase("done");
  }, [today]);

  useEffect(() => {
    const update = () => setCountdown(formatCountdown(msUntilTomorrow()));
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const entry = useMemo(() => {
    if (!player) return null;
    const saved = todaysResult(player, today);
    if (saved) return entryForWord(saved.word) ?? dailyWordFor(player.id, today);
    return dailyWordFor(player.id, today);
  }, [player, today]);

  const score = useMemo(() => (entry ? scoreWord(entry) : null), [entry]);
  const badges = useMemo(() => (score ? badgesFor(score) : []), [score]);
  const rarity = score ? rarityOf(score.total) : "COMMON";

  const visibleProps = score ? score.properties.slice(0, phase === "done" ? score.properties.length : revealed) : [];
  const runningTotal = visibleProps.reduce((sum, p) => sum + p.xp, 0);
  const displayedXp = useCountUp(runningTotal);

  const finish = useCallback(
    async (state: PlayerState, word: string, total: number, discoveries: number) => {
      const updated = recordResult(state, entryForWord(word)!, today);
      setPlayer(updated);
      try {
        await submitResult({
          playerId: updated.id,
          playerName: updated.name,
          word,
          xp: total,
          rarity: rarityOf(total),
          discoveries,
          date: today,
        });
        const scores = await fetchDayScores(today);
        if (scores.length > 1) {
          const below = scores.filter((s) => s < total).length;
          setBeatPercent(Math.round((below / scores.length) * 100));
        }
      } catch {
        /* leaderboard is optional — the local result still stands */
      }
    },
    [today],
  );

  const generate = () => {
    if (!player || !score) return;
    setPhase("suspense");
    timers.current.push(
      setTimeout(() => {
        setPhase("reveal");
        score.properties.forEach((_, index) => {
          timers.current.push(
            setTimeout(
              () => setRevealed(index + 1),
              1400 + index * 620,
            ),
          );
        });
        timers.current.push(
          setTimeout(
            () => {
              setPhase("done");
              void finish(player, score.entry.word, score.total, score.properties.length);
            },
            1400 + score.properties.length * 620 + 400,
          ),
        );
      }, 1100),
    );
  };

  useEffect(() => {
    // Already played today: pull the comparison straight away.
    if (phase !== "done" || !player || !score || beatPercent !== null) return;
    void (async () => {
      try {
        const scores = await fetchDayScores(today);
        if (scores.length > 1) {
          const below = scores.filter((s) => s < score.total).length;
          setBeatPercent(Math.round((below / scores.length) * 100));
        }
      } catch {
        /* ignore */
      }
    })();
  }, [phase, player, score, today, beatPercent]);

  const share = async () => {
    if (!score) return;
    const text = [
      "🧠 WORD RNG",
      "",
      `Today's word: ${score.entry.word}`,
      `⚡ ${score.total.toLocaleString()} XP`,
      `✦ ${rarity}`,
      `🏆 ${score.properties.length} discoveries`,
      beatPercent !== null ? `Rarer than ${beatPercent}% of today's players.` : "",
    ]
      .filter(Boolean)
      .join("\n");
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* clipboard unavailable */
    }
  };

  if (!player || !score || !entry) {
    return (
      <Shell>
        <div className="panel h-72 animate-pulse" />
      </Shell>
    );
  }

  const stats = computeStats(player);

  return (
    <Shell>
      {phase === "idle" && (
        <section className="animate-rise panel flex flex-col items-center gap-6 px-6 py-16 text-center">
          <p className="label-xs">One word. One chance.</p>
          <h1 className="font-display text-4xl font-bold sm:text-5xl">Your word is ready.</h1>
          <p className="max-w-sm text-sm text-muted-foreground">
            Every player gets their own word today. Yours is probably weird — let's find out what's
            hiding inside it.
          </p>
          <button className="btn-hero hover:btn-hero-hover" onClick={generate}>
            Generate my word
          </button>
          {stats.currentStreak > 0 && (
            <p className="text-sm text-muted-foreground">🔥 {stats.currentStreak} day streak</p>
          )}
        </section>
      )}

      {phase === "suspense" && (
        <section className="panel flex h-72 flex-col items-center justify-center gap-4">
          <div className="animate-glow h-16 w-16 rounded-full bg-primary/30 blur-xl" />
          <p className="text-shimmer font-display text-lg font-bold tracking-[0.3em]">SELECTING…</p>
        </section>
      )}

      {(phase === "reveal" || phase === "done") && (
        <div className="space-y-5">
          <section className={`panel animate-rise border px-6 py-8 text-center ${rarityBorderClass[rarity]}`}>
            <p className="label-xs">Your word today</p>
            <h1 className="mt-3 flex flex-wrap justify-center font-display text-3xl font-bold uppercase sm:text-5xl">
              {entry.word.split("").map((letter, index) => (
                <span
                  key={`${letter}-${index}`}
                  className="animate-letter"
                  style={{ animationDelay: `${index * 55}ms` }}
                >
                  {letter}
                </span>
              ))}
            </h1>
            <p className="mt-4 text-sm text-muted-foreground">
              <span className="italic">{entry.partOfSpeech}</span> · {entry.definition}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              {entry.syllables} syllable{entry.syllables === 1 ? "" : "s"} · {entry.origin} origin
            </p>
          </section>

          <section className="panel sticky top-3 z-10 flex items-center justify-between px-6 py-4">
            <span className="label-xs">Total XP</span>
            <span className="font-display text-3xl font-bold tabular-nums text-xp">
              {displayedXp.toLocaleString()}
            </span>
          </section>

          <section className="space-y-2">
            {visibleProps.map((prop) => (
              <PropertyRow
                key={prop.key}
                prop={prop}
                open={openProp === prop.key}
                onToggle={() => setOpenProp(openProp === prop.key ? null : prop.key)}
              />
            ))}
          </section>

          {phase === "done" && (
            <>
              <section className={`panel animate-rise border px-6 py-10 text-center ${rarityBorderClass[rarity]}`}>
                <p className="label-xs">Final score</p>
                <p className="font-display text-5xl font-bold tabular-nums text-xp">
                  {score.total.toLocaleString()} XP
                </p>
                <p className={`mt-2 font-display text-2xl font-bold tracking-[0.25em] ${rarityTextClass[rarity]}`}>
                  {rarity}
                </p>
                <p className="mt-4 text-sm text-muted-foreground">
                  {beatPercent !== null
                    ? `Your word is rarer than ${beatPercent}% of today's players.`
                    : "You're the first player in today — come back later to compare."}
                </p>
                <div className="mt-6 flex flex-wrap justify-center gap-2">
                  <button className="btn-ghost hover:bg-secondary" onClick={share}>
                    {copied ? "Copied!" : "Share result"}
                  </button>
                </div>
              </section>

              {badges.length > 0 && (
                <section className="panel px-6 py-6">
                  <p className="label-xs">Badges unlocked</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {badges.map((badge) => (
                      <span
                        key={badge.id}
                        className="rounded-xl border border-border bg-surface-strong px-3 py-2 text-xs font-medium"
                        title={badge.description}
                      >
                        {badge.icon} {badge.name}
                      </span>
                    ))}
                  </div>
                </section>
              )}

              <section className="panel flex flex-col items-center gap-2 px-6 py-8 text-center">
                <p className="label-xs">Your next word is available in</p>
                <p className="font-display text-3xl font-bold tabular-nums">{countdown}</p>
                <NameEditor
                  player={player}
                  onChange={(name) => {
                    const next = { ...player, name };
                    savePlayer(next);
                    setPlayer(next);
                  }}
                />
              </section>
            </>
          )}
        </div>
      )}
    </Shell>
  );
}

function PropertyRow({
  prop,
  open,
  onToggle,
}: {
  prop: ScoredProperty;
  open: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      className="panel animate-rise block w-full px-5 py-4 text-left transition-colors hover:bg-surface-strong"
    >
      <div className="flex items-center justify-between gap-4">
        <span className="font-display text-sm font-semibold tracking-wide sm:text-base">
          {prop.icon} {prop.label}
          {prop.count > 1 && <span className="text-muted-foreground"> ×{prop.count}</span>}
        </span>
        <span className="font-display text-base font-bold tabular-nums text-xp">
          +{prop.xp.toLocaleString()} XP
        </span>
      </div>
      {open && <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{explainProperty(prop)}</p>}
    </button>
  );
}

function NameEditor({ player, onChange }: { player: PlayerState; onChange: (name: string) => void }) {
  const [value, setValue] = useState(player.name);
  return (
    <label className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
      Leaderboard name
      <input
        value={value}
        maxLength={20}
        onChange={(event) => setValue(event.target.value)}
        onBlur={() => onChange(value.trim() || player.name)}
        className="w-36 rounded-lg border border-input bg-background px-2 py-1 text-sm text-foreground outline-none focus:border-ring"
      />
    </label>
  );
}
