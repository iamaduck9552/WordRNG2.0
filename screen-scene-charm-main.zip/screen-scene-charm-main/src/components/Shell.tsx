import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

const links = [
  { to: "/", label: "Play" },
  { to: "/leaderboard", label: "Leaderboard" },
  { to: "/stats", label: "Stats" },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen">
      <header className="mx-auto flex w-full max-w-3xl items-center justify-between gap-3 px-5 pt-6">
        <Link to="/" className="font-display text-sm font-bold tracking-[0.3em] text-foreground">
          WORD<span className="text-primary">RNG</span>
        </Link>
        <nav className="flex items-center gap-1">
          {links.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="rounded-lg px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
              activeProps={{ className: "bg-secondary text-foreground" }}
              activeOptions={{ exact: link.to === "/" }}
            >
              {link.label}
            </Link>
          ))}
        </nav>
      </header>
      <main className="mx-auto w-full max-w-3xl px-5 pb-24 pt-8">{children}</main>
    </div>
  );
}

export const rarityTextClass: Record<string, string> = {
  COMMON: "text-common",
  UNCOMMON: "text-uncommon",
  RARE: "text-rare",
  EPIC: "text-epic",
  ANOMALY: "text-anomaly",
  MYTHIC: "text-mythic",
};

export const rarityBorderClass: Record<string, string> = {
  COMMON: "border-common/40",
  UNCOMMON: "border-uncommon/40",
  RARE: "border-rare/40",
  EPIC: "border-epic/50",
  ANOMALY: "border-anomaly/50",
  MYTHIC: "border-mythic/60",
};
