import { supabase } from "@/integrations/supabase/client";
import type { RarityName } from "@/lib/scoring";

export interface LeaderboardRow {
  player_id: string;
  player_name: string;
  word: string;
  xp: number;
  rarity: string;
  discoveries: number;
}

export async function submitResult(input: {
  playerId: string;
  playerName: string;
  word: string;
  xp: number;
  rarity: RarityName;
  discoveries: number;
  date: string;
}) {
  const { error } = await supabase.from("daily_results").upsert(
    {
      player_id: input.playerId,
      player_name: input.playerName.slice(0, 20),
      word: input.word,
      xp: input.xp,
      rarity: input.rarity,
      discoveries: input.discoveries,
      play_date: input.date,
    },
    { onConflict: "player_id,play_date", ignoreDuplicates: true },
  );
  if (error && error.code !== "23505") throw error;
}

export async function fetchLeaderboard(date: string) {
  const { data, error } = await supabase
    .from("daily_results")
    .select("player_id, player_name, word, xp, rarity, discoveries")
    .eq("play_date", date)
    .order("xp", { ascending: false })
    .limit(50);
  if (error) throw error;
  return (data ?? []) as LeaderboardRow[];
}

export async function fetchDayScores(date: string) {
  const { data, error } = await supabase
    .from("daily_results")
    .select("xp")
    .eq("play_date", date)
    .limit(1000);
  if (error) throw error;
  return (data ?? []).map((row) => row.xp as number);
}
