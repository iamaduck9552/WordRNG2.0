import { WORDS, WORD_BY_TEXT, type WordEntry } from "@/data/words";
import { scoreWord, rarityOf, type RarityName } from "@/lib/scoring";
import { badgesFor } from "@/lib/badges";

/**
 * PLAYER SYSTEM + DAILY WORD ENGINE
 *
 * The player identity is an anonymous persistent id in local storage.
 * The daily word is deterministic: hash(playerId + localDate) picks the index,
 * so refreshing never rerolls and the word changes at local midnight.
 */

const PLAYER_KEY = "wordrng:player";

export interface HistoryEntry {
  date: string; // YYYY-MM-DD local
  word: string;
  xp: number;
  rarity: RarityName;
  discoveries: number;
}

export interface PlayerState {
  id: string;
  name: string;
  history: HistoryEntry[];
  badges: string[];
}

export function localDateKey(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

const ADJECTIVES = ["Lucky", "Quiet", "Odd", "Rapid", "Velvet", "Hidden", "Neon", "Lunar", "Wild", "Brave"];
const NOUNS = ["Lexicon", "Vowel", "Glyph", "Syllable", "Cipher", "Rune", "Comma", "Phoneme", "Quill", "Echo"];

function randomName() {
  const a = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)]!;
  const n = NOUNS[Math.floor(Math.random() * NOUNS.length)]!;
  return `${a}${n}`;
}

function randomId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `p-${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
}

export function loadPlayer(): PlayerState {
  if (typeof window === "undefined") {
    return { id: "ssr-placeholder-id", name: "Player", history: [], badges: [] };
  }
  const raw = window.localStorage.getItem(PLAYER_KEY);
  if (raw) {
    try {
      const parsed = JSON.parse(raw) as PlayerState;
      if (parsed.id) {
        return {
          id: parsed.id,
          name: parsed.name || randomName(),
          history: Array.isArray(parsed.history) ? parsed.history : [],
          badges: Array.isArray(parsed.badges) ? parsed.badges : [],
        };
      }
    } catch {
      /* fall through and create a fresh player */
    }
  }
  const fresh: PlayerState = { id: randomId(), name: randomName(), history: [], badges: [] };
  window.localStorage.setItem(PLAYER_KEY, JSON.stringify(fresh));
  return fresh;
}

export function savePlayer(state: PlayerState) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(PLAYER_KEY, JSON.stringify(state));
}

/* ------------------------------------------------------- DAILY WORD ------ */

function hashString(value: string) {
  // FNV-1a
  let hash = 0x811c9dc5;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash >>> 0;
}

export function dailyWordFor(playerId: string, date = localDateKey()): WordEntry {
  const index = hashString(`${playerId}|${date}`) % WORDS.length;
  return WORDS[index]!;
}

export function entryForWord(word: string): WordEntry | undefined {
  return WORD_BY_TEXT.get(word.toUpperCase());
}

export function msUntilTomorrow(now = new Date()) {
  const next = new Date(now);
  next.setHours(24, 0, 0, 0);
  return next.getTime() - now.getTime();
}

export function formatCountdown(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = String(Math.floor(total / 3600)).padStart(2, "0");
  const m = String(Math.floor((total % 3600) / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  return `${h}:${m}:${s}`;
}

/* ------------------------------------------------------------ RESULTS ---- */

export function recordResult(state: PlayerState, entry: WordEntry, date = localDateKey()): PlayerState {
  if (state.history.some((h) => h.date === date)) return state;
  const score = scoreWord(entry);
  const earned = badgesFor(score).map((b) => b.id);
  const next: PlayerState = {
    ...state,
    history: [
      { date, word: entry.word, xp: score.total, rarity: rarityOf(score.total), discoveries: score.properties.length },
      ...state.history,
    ].slice(0, 365),
    badges: Array.from(new Set([...state.badges, ...earned])),
  };
  savePlayer(next);
  return next;
}

export function todaysResult(state: PlayerState, date = localDateKey()) {
  return state.history.find((h) => h.date === date);
}

/* -------------------------------------------------------------- STATS ---- */

export interface PlayerStats {
  currentStreak: number;
  longestStreak: number;
  totalWords: number;
  totalXp: number;
  highestXp: number;
  averageXp: number;
  highestRarity: RarityName | "—";
}

const RARITY_RANK: Record<string, number> = {
  COMMON: 0,
  UNCOMMON: 1,
  RARE: 2,
  EPIC: 3,
  ANOMALY: 4,
  MYTHIC: 5,
};

function shiftDate(key: string, days: number) {
  const [y, m, d] = key.split("-").map(Number);
  const date = new Date(y!, m! - 1, d!);
  date.setDate(date.getDate() + days);
  return localDateKey(date);
}

export function computeStats(state: PlayerState): PlayerStats {
  const history = [...state.history].sort((a, b) => (a.date < b.date ? 1 : -1));
  const dates = new Set(history.map((h) => h.date));
  const today = localDateKey();

  let currentStreak = 0;
  let cursor = dates.has(today) ? today : shiftDate(today, -1);
  while (dates.has(cursor)) {
    currentStreak += 1;
    cursor = shiftDate(cursor, -1);
  }

  let longestStreak = 0;
  let run = 0;
  const sortedAsc = [...dates].sort();
  let previous: string | null = null;
  for (const date of sortedAsc) {
    run = previous && shiftDate(previous, 1) === date ? run + 1 : 1;
    longestStreak = Math.max(longestStreak, run);
    previous = date;
  }

  const totalXp = history.reduce((sum, h) => sum + h.xp, 0);
  const highestXp = history.reduce((max, h) => Math.max(max, h.xp), 0);
  const highestRarity = history.reduce<RarityName | "—">((best, h) => {
    if (best === "—") return h.rarity;
    return RARITY_RANK[h.rarity]! > RARITY_RANK[best]! ? h.rarity : best;
  }, "—");

  return {
    currentStreak,
    longestStreak,
    totalWords: history.length,
    totalXp,
    highestXp,
    averageXp: history.length ? Math.round(totalXp / history.length) : 0,
    highestRarity,
  };
}
