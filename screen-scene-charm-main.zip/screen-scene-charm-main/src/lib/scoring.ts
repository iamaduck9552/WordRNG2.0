import { WORDS, type WordEntry } from "@/data/words";
import { analyse, type DetectedProperty } from "@/lib/properties";

/**
 * SCORING ENGINE
 *
 * Property XP is derived once, from the reference dictionary:
 *   frequency = wordsContainingProperty / totalWords
 *   xp        = min(1000, round(-100 * ln(frequency)))
 *
 * The table is fixed for the lifetime of the dictionary: the same property is
 * always worth the same XP, in every word. Nothing is random, nothing is
 * hand-tuned, and nothing is model-generated.
 */

export interface PropertyStat {
  key: string;
  frequency: number;
  xp: number;
}

export interface ScoredProperty extends DetectedProperty {
  xp: number; // total for this property (xp per occurrence * count)
  xpEach: number;
  frequency: number;
}

export interface WordScore {
  entry: WordEntry;
  properties: ScoredProperty[];
  total: number;
}

const TOTAL_WORDS = WORDS.length;

function buildTable(): Map<string, PropertyStat> {
  const occurrences = new Map<string, number>();
  for (const entry of WORDS) {
    const keys = new Set(analyse(entry).map((p) => p.key));
    for (const key of keys) {
      occurrences.set(key, (occurrences.get(key) ?? 0) + 1);
    }
  }
  const table = new Map<string, PropertyStat>();
  for (const [key, count] of occurrences) {
    const frequency = count / TOTAL_WORDS;
    const xp = Math.min(1000, Math.round(-100 * Math.log(frequency)));
    table.set(key, { key, frequency, xp });
  }
  return table;
}

export const XP_TABLE: Map<string, PropertyStat> = buildTable();

function statFor(key: string): PropertyStat {
  const existing = XP_TABLE.get(key);
  if (existing) return existing;
  // A property no dictionary word has: treat it as maximally rare.
  const frequency = 1 / (TOTAL_WORDS * 2);
  return { key, frequency, xp: Math.min(1000, Math.round(-100 * Math.log(frequency))) };
}

export function scoreWord(entry: WordEntry): WordScore {
  const properties = analyse(entry)
    .map((prop) => {
      const stat = statFor(prop.key);
      return {
        ...prop,
        xpEach: stat.xp,
        xp: stat.xp * prop.count,
        frequency: stat.frequency,
      } satisfies ScoredProperty;
    })
    .sort((a, b) => a.xp - b.xp);

  return {
    entry,
    properties,
    total: properties.reduce((sum, p) => sum + p.xp, 0),
  };
}

export function explainProperty(prop: ScoredProperty) {
  const pct = prop.frequency * 100;
  const shown = pct >= 1 ? pct.toFixed(1) : pct.toFixed(2);
  return `${shown}% of words in our reference dictionary have this property, so it is worth ${prop.xpEach.toLocaleString()} XP${
    prop.perOccurrence ? " per occurrence" : ""
  }.`;
}

/* ---------------------------------------------------------------- RARITY -- */

export const RARITY_TIERS = [
  { name: "COMMON", from: 0 },
  { name: "UNCOMMON", from: 50 },
  { name: "RARE", from: 75 },
  { name: "EPIC", from: 95 },
  { name: "ANOMALY", from: 99 },
  { name: "MYTHIC", from: 99.9 },
] as const;

export type RarityName = (typeof RARITY_TIERS)[number]["name"];

const ALL_TOTALS = WORDS.map((entry) => scoreWord(entry).total).sort((a, b) => a - b);

function percentileAt(p: number) {
  const index = Math.min(ALL_TOTALS.length - 1, Math.floor((p / 100) * ALL_TOTALS.length));
  return ALL_TOTALS[index]!;
}

export const RARITY_THRESHOLDS = RARITY_TIERS.map((tier) => ({
  name: tier.name,
  minScore: percentileAt(tier.from),
}));

export function percentileOf(total: number) {
  let below = 0;
  for (const value of ALL_TOTALS) {
    if (value < total) below += 1;
    else break;
  }
  return (below / ALL_TOTALS.length) * 100;
}

export function rarityOf(total: number): RarityName {
  const pct = percentileOf(total);
  let name: RarityName = "COMMON";
  for (const tier of RARITY_TIERS) {
    if (pct >= tier.from) name = tier.name;
  }
  return name;
}

export const RARITY_ORDER: RarityName[] = RARITY_TIERS.map((t) => t.name);
