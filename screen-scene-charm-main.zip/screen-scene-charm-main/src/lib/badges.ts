import type { WordScore } from "@/lib/scoring";

export interface BadgeDef {
  id: string;
  icon: string;
  name: string;
  description: string;
  hint: string;
  test: (score: WordScore) => boolean;
}

const has = (score: WordScore, key: string) => score.properties.some((p) => p.key === key);
const anyKey = (score: WordScore, prefix: string) =>
  score.properties.some((p) => p.key.startsWith(prefix));

export const BADGES: BadgeDef[] = [
  {
    id: "double-trouble",
    icon: "🔁",
    name: "DOUBLE TROUBLE",
    description: "Your word contained a repeated letter.",
    hint: "Some letters like company.",
    test: (s) => anyKey(s, "DOUBLE_"),
  },
  {
    id: "triple-threat",
    icon: "🔂",
    name: "TRIPLE THREAT",
    description: "Three identical letters in a row.",
    hint: "Two is never enough.",
    test: (s) => anyKey(s, "TRIPLE_"),
  },
  {
    id: "rare-letter",
    icon: "💎",
    name: "RARE LETTER",
    description: "Your word contained Q, X, Z or J.",
    hint: "The expensive end of the alphabet.",
    test: (s) => ["HAS_Q", "HAS_X", "HAS_Z", "HAS_J"].some((k) => has(s, k)),
  },
  {
    id: "jackpot",
    icon: "💠",
    name: "JACKPOT",
    description: "Two or more rare letters in one word.",
    hint: "Greedy.",
    test: (s) => has(s, "MULTI_RARE_LETTERS"),
  },
  {
    id: "mirror",
    icon: "🪞",
    name: "MIRROR",
    description: "A palindrome.",
    hint: "Reads the same both ways.",
    test: (s) => has(s, "PALINDROME"),
  },
  {
    id: "long-boi",
    icon: "📏",
    name: "LONG BOI",
    description: "A word of 12 letters or more.",
    hint: "Size matters here.",
    test: (s) => s.entry.word.length >= 12,
  },
  {
    id: "tiny",
    icon: "🤏",
    name: "TINY",
    description: "A word of 5 letters or fewer.",
    hint: "Short and sharp.",
    test: (s) => s.entry.word.length <= 5,
  },
  {
    id: "vowel-monster",
    icon: "🌈",
    name: "VOWEL MONSTER",
    description: "An unusually vowel-heavy word.",
    hint: "Mostly open mouth.",
    test: (s) => has(s, "VOWEL_HEAVY"),
  },
  {
    id: "consonant-wall",
    icon: "🧱",
    name: "CONSONANT WALL",
    description: "Barely a vowel in sight.",
    hint: "Try pronouncing it.",
    test: (s) => has(s, "CONSONANT_HEAVY") || has(s, "NO_VOWELS"),
  },
  {
    id: "full-house",
    icon: "🏠",
    name: "FULL HOUSE",
    description: "Contains every vowel A, E, I, O and U.",
    hint: "Collect them all.",
    test: (s) => has(s, "ALL_VOWELS"),
  },
  {
    id: "world-traveller",
    icon: "🌍",
    name: "WORLD TRAVELLER",
    description: "A word borrowed from another language.",
    hint: "Not from around here.",
    test: (s) => has(s, "FOREIGN_ORIGIN"),
  },
  {
    id: "forgotten",
    icon: "👻",
    name: "FORGOTTEN",
    description: "An archaic word nobody uses anymore.",
    hint: "Dust on the pages.",
    test: (s) => has(s, "ARCHAIC"),
  },
  {
    id: "lab-coat",
    icon: "🔬",
    name: "LAB COAT",
    description: "A specialist or technical term.",
    hint: "Somebody studies this for a living.",
    test: (s) => has(s, "TECHNICAL"),
  },
  {
    id: "pattern-breaker",
    icon: "🧬",
    name: "PATTERN BREAKER",
    description: "A repeated three-letter sequence.",
    hint: "Patterns within patterns.",
    test: (s) => has(s, "REPEATED_TRIGRAM"),
  },
  {
    id: "bookends",
    icon: "🔗",
    name: "BOOKENDS",
    description: "Starts and ends with the same letter.",
    hint: "A tidy finish.",
    test: (s) => has(s, "SAME_ENDS"),
  },
  {
    id: "tongue-twister",
    icon: "⛰️",
    name: "TONGUE TWISTER",
    description: "Four consonants in a row.",
    hint: "Good luck saying it.",
    test: (s) => has(s, "FOUR_CONSONANTS_RUN"),
  },
  {
    id: "vowel-river",
    icon: "🌊",
    name: "VOWEL RIVER",
    description: "Four vowels in a row.",
    hint: "Aaaa... eee.",
    test: (s) => has(s, "FOUR_VOWELS_RUN"),
  },
  {
    id: "snowflake",
    icon: "❄️",
    name: "SNOWFLAKE",
    description: "A long word where no letter repeats.",
    hint: "Everything exactly once.",
    test: (s) => has(s, "ALL_UNIQUE_LONG"),
  },
  {
    id: "alphabetical",
    icon: "🔠",
    name: "IN ORDER",
    description: "Letters appear in alphabetical order.",
    hint: "A to Z, no cheating.",
    test: (s) => has(s, "ALPHA_ORDER") || has(s, "REVERSE_ALPHA_ORDER"),
  },
  {
    id: "symphony",
    icon: "🎵",
    name: "SYMPHONY",
    description: "Five syllables or more.",
    hint: "A mouthful.",
    test: (s) => s.entry.syllables >= 5,
  },
  {
    id: "echo",
    icon: "🔊",
    name: "ECHO",
    description: "A word that imitates a sound.",
    hint: "Say it out loud.",
    test: (s) => has(s, "ONOMATOPOEIC"),
  },
  {
    id: "two-faced",
    icon: "🪄",
    name: "TWO-FACED",
    description: "A word with multiple distinct meanings.",
    hint: "Depends who's asking.",
    test: (s) => has(s, "POLYSEMOUS"),
  },
  {
    id: "thousand-club",
    icon: "⚡",
    name: "THOUSAND CLUB",
    description: "Scored 1,000 XP or more in a single day.",
    hint: "Score big.",
    test: (s) => s.total >= 1000,
  },
  {
    id: "mythic-hunter",
    icon: "🏆",
    name: "MYTHIC HUNTER",
    description: "Scored 2,000 XP or more in a single day.",
    hint: "The very top of the distribution.",
    test: (s) => s.total >= 2000,
  },
];

export function badgesFor(score: WordScore) {
  return BADGES.filter((badge) => badge.test(score));
}
