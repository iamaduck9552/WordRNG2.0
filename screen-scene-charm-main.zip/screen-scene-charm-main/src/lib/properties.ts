import type { WordEntry } from "@/data/words";

/**
 * PROPERTY ENGINE
 *
 * analyse(entry) returns every property a word possesses.
 * Each property has:
 *  - key: stable id used by the fixed XP table
 *  - count: how many times it is awarded (per-occurrence properties can be > 1)
 *
 * Per-occurrence properties: repeated letter pairs, triples, repeated sequences.
 * Everything else is awarded once per word.
 */

export interface DetectedProperty {
  key: string;
  label: string;
  icon: string;
  category: "length" | "letters" | "repeats" | "vowels" | "structure" | "linguistic";
  count: number;
  perOccurrence: boolean;
}

const VOWELS = new Set(["A", "E", "I", "O", "U"]);
const RARE_LETTERS = ["J", "Q", "X", "Z"];

function isVowel(ch: string) {
  return VOWELS.has(ch);
}

function longestRun(word: string, predicate: (ch: string) => boolean) {
  let best = 0;
  let run = 0;
  for (const ch of word) {
    if (predicate(ch)) {
      run += 1;
      best = Math.max(best, run);
    } else {
      run = 0;
    }
  }
  return best;
}

function push(list: DetectedProperty[], prop: DetectedProperty) {
  list.push(prop);
}

export function analyse(entry: WordEntry): DetectedProperty[] {
  const word = entry.word.toUpperCase();
  const letters = word.split("");
  const props: DetectedProperty[] = [];

  // --- LENGTH -------------------------------------------------------------
  push(props, {
    key: `LENGTH_${word.length}`,
    label: `${word.length} LETTERS`,
    icon: "📏",
    category: "length",
    count: 1,
    perOccurrence: false,
  });

  // --- LETTERS ------------------------------------------------------------
  for (const letter of ["E", "A", "I", "O", "U", "Y", "J", "Q", "X", "Z", "K", "V", "W"]) {
    if (word.includes(letter)) {
      push(props, {
        key: `HAS_${letter}`,
        label: `CONTAINS ${letter}`,
        icon: RARE_LETTERS.includes(letter) ? "💎" : "🔤",
        category: "letters",
        count: 1,
        perOccurrence: false,
      });
    }
  }

  const rareCount = RARE_LETTERS.filter((l) => word.includes(l)).length;
  if (rareCount >= 2) {
    push(props, {
      key: "MULTI_RARE_LETTERS",
      label: "MULTIPLE RARE LETTERS",
      icon: "💠",
      category: "letters",
      count: 1,
      perOccurrence: false,
    });
  }

  if (["A", "E", "I", "O", "U"].every((v) => word.includes(v))) {
    push(props, {
      key: "ALL_VOWELS",
      label: "CONTAINS EVERY VOWEL",
      icon: "🌈",
      category: "letters",
      count: 1,
      perOccurrence: false,
    });
  }

  if (!letters.some(isVowel)) {
    push(props, {
      key: "NO_VOWELS",
      label: "NO STANDARD VOWEL",
      icon: "🧱",
      category: "letters",
      count: 1,
      perOccurrence: false,
    });
  }

  // --- REPEATED LETTERS (per occurrence) ----------------------------------
  const doubleCounts = new Map<string, number>();
  const tripleLetters = new Set<string>();
  let i = 0;
  while (i < letters.length) {
    let j = i;
    while (j + 1 < letters.length && letters[j + 1] === letters[i]) j += 1;
    const runLength = j - i + 1;
    const letter = letters[i]!;
    if (runLength >= 3) {
      tripleLetters.add(letter);
    } else if (runLength === 2) {
      doubleCounts.set(letter, (doubleCounts.get(letter) ?? 0) + 1);
    }
    i = j + 1;
  }
  for (const [letter, count] of doubleCounts) {
    push(props, {
      key: `DOUBLE_${letter}`,
      label: `DOUBLE ${letter}`,
      icon: "🔁",
      category: "repeats",
      count,
      perOccurrence: true,
    });
  }
  for (const letter of tripleLetters) {
    push(props, {
      key: `TRIPLE_${letter}`,
      label: `TRIPLE ${letter}`,
      icon: "🔂",
      category: "repeats",
      count: 1,
      perOccurrence: true,
    });
  }

  // repeated 2 and 3 letter sequences (non-overlapping duplicates)
  const repeatedPairs = countRepeatedSequences(word, 2);
  if (repeatedPairs > 0) {
    push(props, {
      key: "REPEATED_BIGRAM",
      label: "REPEATED 2-LETTER SEQUENCE",
      icon: "🧩",
      category: "repeats",
      count: repeatedPairs,
      perOccurrence: true,
    });
  }
  const repeatedTriples = countRepeatedSequences(word, 3);
  if (repeatedTriples > 0) {
    push(props, {
      key: "REPEATED_TRIGRAM",
      label: "REPEATED 3-LETTER SEQUENCE",
      icon: "🧬",
      category: "repeats",
      count: repeatedTriples,
      perOccurrence: true,
    });
  }

  // --- VOWEL / CONSONANT --------------------------------------------------
  const vowelCount = letters.filter(isVowel).length;
  const ratio = vowelCount / letters.length;
  if (ratio >= 0.6) {
    push(props, {
      key: "VOWEL_HEAVY",
      label: "VOWEL HEAVY",
      icon: "🫧",
      category: "vowels",
      count: 1,
      perOccurrence: false,
    });
  }
  if (ratio <= 0.25) {
    push(props, {
      key: "CONSONANT_HEAVY",
      label: "CONSONANT HEAVY",
      icon: "🪨",
      category: "vowels",
      count: 1,
      perOccurrence: false,
    });
  }
  const vowelRun = longestRun(word, isVowel);
  if (vowelRun >= 4) {
    push(props, {
      key: "FOUR_VOWELS_RUN",
      label: "FOUR CONSECUTIVE VOWELS",
      icon: "🌊",
      category: "vowels",
      count: 1,
      perOccurrence: false,
    });
  } else if (vowelRun === 3) {
    push(props, {
      key: "THREE_VOWELS_RUN",
      label: "THREE CONSECUTIVE VOWELS",
      icon: "💧",
      category: "vowels",
      count: 1,
      perOccurrence: false,
    });
  }
  const consRun = longestRun(word, (ch) => !isVowel(ch));
  if (consRun >= 4) {
    push(props, {
      key: "FOUR_CONSONANTS_RUN",
      label: "FOUR CONSECUTIVE CONSONANTS",
      icon: "⛰️",
      category: "vowels",
      count: 1,
      perOccurrence: false,
    });
  } else if (consRun === 3) {
    push(props, {
      key: "THREE_CONSONANTS_RUN",
      label: "THREE CONSECUTIVE CONSONANTS",
      icon: "🧗",
      category: "vowels",
      count: 1,
      perOccurrence: false,
    });
  }
  if (letters.every((ch, idx) => isVowel(ch) === (isVowel(letters[0]!) ? idx % 2 === 0 : idx % 2 === 1))) {
    push(props, {
      key: "ALTERNATING",
      label: "ALTERNATING VOWEL / CONSONANT",
      icon: "🌀",
      category: "vowels",
      count: 1,
      perOccurrence: false,
    });
  }

  // --- STRUCTURE ----------------------------------------------------------
  if (letters[0] === letters[letters.length - 1]) {
    push(props, {
      key: "SAME_ENDS",
      label: "SAME FIRST AND LAST LETTER",
      icon: "🔗",
      category: "structure",
      count: 1,
      perOccurrence: false,
    });
  }
  if (word.length > 2 && word === [...word].reverse().join("")) {
    push(props, {
      key: "PALINDROME",
      label: "PALINDROME",
      icon: "🪞",
      category: "structure",
      count: 1,
      perOccurrence: false,
    });
  }
  if (isSorted(letters, (a, b) => a <= b)) {
    push(props, {
      key: "ALPHA_ORDER",
      label: "ALPHABETICALLY ORDERED",
      icon: "🔠",
      category: "structure",
      count: 1,
      perOccurrence: false,
    });
  }
  if (isSorted(letters, (a, b) => a >= b)) {
    push(props, {
      key: "REVERSE_ALPHA_ORDER",
      label: "REVERSE ALPHABETICAL",
      icon: "🔡",
      category: "structure",
      count: 1,
      perOccurrence: false,
    });
  }
  if (word.length >= 6 && word.slice(0, 2) === word.slice(2, 4)) {
    push(props, {
      key: "REPEATED_PREFIX",
      label: "REPEATED PREFIX",
      icon: "🚪",
      category: "structure",
      count: 1,
      perOccurrence: false,
    });
  }
  if (word.length >= 6 && word.slice(-2) === word.slice(-4, -2)) {
    push(props, {
      key: "REPEATED_SUFFIX",
      label: "REPEATED SUFFIX",
      icon: "🏁",
      category: "structure",
      count: 1,
      perOccurrence: false,
    });
  }
  if (new Set(letters).size === letters.length && letters.length >= 8) {
    push(props, {
      key: "ALL_UNIQUE_LONG",
      label: "NO LETTER REPEATS",
      icon: "❄️",
      category: "structure",
      count: 1,
      perOccurrence: false,
    });
  }

  // --- LINGUISTIC ---------------------------------------------------------
  push(props, {
    key: `SYLLABLES_${entry.syllables}`,
    label: `${entry.syllables} SYLLABLE${entry.syllables === 1 ? "" : "S"}`,
    icon: "🎵",
    category: "linguistic",
    count: 1,
    perOccurrence: false,
  });

  if (entry.origin.toLowerCase() !== "english") {
    push(props, {
      key: "FOREIGN_ORIGIN",
      label: `${entry.origin.toUpperCase()} ORIGIN`,
      icon: "🌍",
      category: "linguistic",
      count: 1,
      perOccurrence: false,
    });
  }
  if (entry.tags.includes("archaic")) {
    push(props, {
      key: "ARCHAIC",
      label: "ARCHAIC WORD",
      icon: "👻",
      category: "linguistic",
      count: 1,
      perOccurrence: false,
    });
  }
  if (entry.tags.includes("technical")) {
    push(props, {
      key: "TECHNICAL",
      label: "SPECIALIST TERM",
      icon: "🔬",
      category: "linguistic",
      count: 1,
      perOccurrence: false,
    });
  }
  if (entry.tags.includes("polysemous")) {
    push(props, {
      key: "POLYSEMOUS",
      label: "MULTIPLE MEANINGS",
      icon: "🪄",
      category: "linguistic",
      count: 1,
      perOccurrence: false,
    });
  }
  if (entry.tags.includes("onomatopoeic")) {
    push(props, {
      key: "ONOMATOPOEIC",
      label: "SOUND WORD",
      icon: "🔊",
      category: "linguistic",
      count: 1,
      perOccurrence: false,
    });
  }

  return props;
}

function isSorted(letters: string[], cmp: (a: string, b: string) => boolean) {
  for (let i = 1; i < letters.length; i += 1) {
    if (!cmp(letters[i - 1]!, letters[i]!)) return false;
  }
  return true;
}

function countRepeatedSequences(word: string, size: number) {
  const seen = new Map<string, number>();
  for (let i = 0; i + size <= word.length; i += 1) {
    const seq = word.slice(i, i + size);
    if (new Set(seq).size === 1) continue; // handled by double/triple letters
    seen.set(seq, (seen.get(seq) ?? 0) + 1);
  }
  let extras = 0;
  for (const count of seen.values()) {
    if (count > 1) extras += count - 1;
  }
  return extras;
}
