CREATE TABLE public.daily_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id text NOT NULL CHECK (char_length(player_id) BETWEEN 8 AND 64),
  player_name text NOT NULL CHECK (char_length(player_name) BETWEEN 1 AND 20),
  word text NOT NULL CHECK (char_length(word) BETWEEN 2 AND 40),
  xp integer NOT NULL CHECK (xp >= 0 AND xp <= 100000),
  rarity text NOT NULL CHECK (char_length(rarity) BETWEEN 2 AND 20),
  discoveries integer NOT NULL DEFAULT 0 CHECK (discoveries >= 0 AND discoveries <= 200),
  play_date date NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (player_id, play_date)
);

CREATE INDEX daily_results_date_xp_idx ON public.daily_results (play_date, xp DESC);

GRANT SELECT, INSERT ON public.daily_results TO anon;
GRANT SELECT, INSERT ON public.daily_results TO authenticated;
GRANT ALL ON public.daily_results TO service_role;

ALTER TABLE public.daily_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read results" ON public.daily_results FOR SELECT USING (true);
CREATE POLICY "Anyone can submit a result" ON public.daily_results FOR INSERT WITH CHECK (true);